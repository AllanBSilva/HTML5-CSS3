import fs from 'fs';

const inputJsonFilepath = `${__dirname}/entrada.json`;
const outputJsonFilepath = `${__dirname}/saida.json`;
const outputJsonFilepath2 = `${__dirname}/saida-legivel.json`;
